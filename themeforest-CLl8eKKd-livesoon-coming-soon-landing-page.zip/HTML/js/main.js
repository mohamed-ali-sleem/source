﻿ 
'use strict';
var $window = $(window),
    $document = $(document);
document.write('<script async src="https://www.youtube.com/iframe_api"></script>'); 

$window.on({
    'load': function () {
        /* Preloader */
        $(".loader").fadeOut();

        // Add YouTube video background
        var bgVideo = $('#bg-video');
        if (bgVideo.length) {
            bgVideo.YTPlayer();
            $('#bg-video-volume').on("click", function (e) {
                var bgVideoVol = $(this);
                e.preventDefault();
                if (bgVideoVol.hasClass('fa-volume-off')) {
                    bgVideoVol.removeClass('fa-volume-off').addClass('fa-volume-up').attr('title', 'Mute');
                    bgVideo.YTPUnmute();
                } else {
                    bgVideoVol.removeClass('fa-volume-up').addClass('fa-volume-off').attr('title', 'Unmute');
                    bgVideo.YTPMute();
                }
            });
            $('#bg-video-play').click(function (e) {
                var bgVideoPlay = $(this);
                e.preventDefault();
                if (bgVideoPlay.hasClass('fa-pause')) {
                    bgVideoPlay.removeClass('fa-pause').addClass('fa-play').attr('title', 'Play');
                    bgVideo.YTPPause();
                } else {
                    bgVideoPlay.removeClass('fa-play').addClass('fa-pause').attr('title', 'Pause');
                    bgVideo.YTPPlay();
                }
            });
        }

        // =================================================================================
        // Image Slider
        // =================================================================================
        var imgSlider = $('#slides');
        if (imgSlider.length) {
            imgSlider.superslides({
                animation: 'fade',
                play: 10000
            });
        }
        // =================================================================================
        // Countdown
        // =================================================================================
        var countDown = $('.countdown');
        if (countDown.length) {
            countDown.each(function () {
                var item = $(this),
                    date = new Date(),
                    settings = [],
                    time = item[0].getAttribute('data-time'),
                    type = item[0].getAttribute('data-type'),
                    format = item[0].getAttribute('data-format');
                date.setTime(Date.parse(time)).toLocaleString();
                settings[type] = date;
                settings['format'] = format;
                item.countdown(settings);
            });
        }
        // =================================================================================
        // Swiper
        // =================================================================================
        var slider_main = $('.slider-main');

        if (slider_main.length) {
            var slider_main = new Swiper('.slider-main', {
                nextButton: '.arrow-next',
                prevButton: '.arrow-prev',
                speed: 600,
                autoHeight: true,
            });
            slider_main.slideTo(1, 1, true);
        }
        // =================================================================================
        // particleground
        // =================================================================================
        var particleground = $('#particleground');
        if (particleground.length) {
            $('#particleground').particleground({
                dotColor: '#f2f2f2',
                lineColor: '#f2f2f2'
            });
        }
        // =================================================================================
        // particlesjs
        // =================================================================================
        var particles_js = $('#particles-js');
        if (particles_js.length) {
            particlesJS('particles-js',
                {
                    "particles": {
                        "number": {
                            "value": 80,
                            "density": {
                                "enable": true,
                                "value_area": 800
                            }
                        },
                        "color": {
                            "value": "#ffffff"
                        },
                        "shape": {
                            "type": "circle",
                            "stroke": {
                                "width": 0,
                                "color": "#000000"
                            },
                            "polygon": {
                                "nb_sides": 5
                            },
                            "image": {
                                "src": "img/github.svg",
                                "width": 100,
                                "height": 100
                            }
                        },
                        "opacity": {
                            "value": 0.5,
                            "random": false,
                            "anim": {
                                "enable": false,
                                "speed": 1,
                                "opacity_min": 0.1,
                                "sync": false
                            }
                        },
                        "size": {
                            "value": 5,
                            "random": true,
                            "anim": {
                                "enable": false,
                                "speed": 40,
                                "size_min": 0.1,
                                "sync": false
                            }
                        },
                        "line_linked": {
                            "enable": true,
                            "distance": 150,
                            "color": "#ffffff",
                            "opacity": 0.4,
                            "width": 1
                        },
                        "move": {
                            "enable": true,
                            "speed": 6,
                            "direction": "none",
                            "random": false,
                            "straight": false,
                            "out_mode": "out",
                            "attract": {
                                "enable": false,
                                "rotateX": 600,
                                "rotateY": 1200
                            }
                        }
                    },
                    "interactivity": {
                        "detect_on": "canvas",
                        "events": {
                            "onhover": {
                                "enable": true,
                                "mode": "repulse"
                            },
                            "onclick": {
                                "enable": true,
                                "mode": "push"
                            },
                            "resize": true
                        },
                        "modes": {
                            "grab": {
                                "distance": 400,
                                "line_linked": {
                                    "opacity": 1
                                }
                            },
                            "bubble": {
                                "distance": 400,
                                "size": 40,
                                "duration": 2,
                                "opacity": 8,
                                "speed": 3
                            },
                            "repulse": {
                                "distance": 200
                            },
                            "push": {
                                "particles_nb": 4
                            },
                            "remove": {
                                "particles_nb": 2
                            }
                        }
                    },
                    "retina_detect": true,
                    "config_demo": {
                        "hide_card": false,
                        "background_color": "#b61924",
                        "background_image": "",
                        "background_position": "50% 50%",
                        "background_repeat": "no-repeat",
                        "background_size": "cover"
                    }
                }

            );
        }

        // =================================================================================
        // tooltip
        // =================================================================================
        $('[data-toggle="tooltip"]').tooltip();

        // =================================================================================
        // menu slide
        // =================================================================================
        $(".menu a").on("click", function () {
            var slide = $(this).data("slide");
            slider_main.slideTo(slide, 600, true);
        });
        $(".menu-opener").on("click", function () {
            $(".menu-opener, .menu-opener-inner, .menu").toggleClass("active");
        });



        // =================================================================================
        // contact-form
        // =================================================================================
        var form = $('#contact-form');
        form.submit(function (event) {
            event.preventDefault();
            var form_status = $('<div class="form-status"></div>');
            $.ajax({
                type: "POST",
                url: $(this).attr('action'),
                beforeSend: function () {
                    form.prepend(form_status.html('<p><i class="fa fa-spinner fa-spin"></i> Email is sending...</p>').fadeIn());
                }
            }).done(function (data) {
                form_status.html('<div id="alert" class="alert alert-success">Thank you for contact us. As early as possible  we will contact you  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            });
        });


        var imgSlider = $('#slides');
        if (imgSlider.length) {
            imgSlider.superslides({
                animation: 'fade',
                play: 10000
            });
        }

        // =================================================================================
        // Background ripple
        // =================================================================================
        var ripple = $('#page-ripple');

        if (ripple.length) {
            ripple.ripples({
                resolution: 512,
                dropRadius: 100, //px
                perturbance: 0.01,
                interactive: false
            });

            setInterval(function () {
                var $el = ripple;
                var x = Math.random() * $el.outerWidth();
                var y = Math.random() * $el.outerHeight();
                var dropRadius = 20;
                var strength = 0.04 + Math.random() * 0.01;

                $el.ripples('drop', x, y, dropRadius, strength);
            }, 500);
        }
        // =================================================================================
        //  Background Flat Surface Shader
        // =================================================================================
        /* ------------------------------
            Options
            ------------------------------ */

        var flatSurface = $('#bg-fss');

        if (flatSurface.length) {
            var MESH = {
                width: 1.2,
                height: 1.2,
                depth: 0,
                segments: 16,
                slices: 8,
                xRange: 0.8,
                yRange: 0.1,
                zRange: 1.0,
                ambient: '#555555',
                diffuse: '#ffffff',
                speed: 0.002
            };

            var LIGHT = {
                count: 2,
                xyScalar: 1,
                zOffset: 100,
                ambient: flatSurface.data('ambient'),
                diffuse: flatSurface.data('diffuse'),
                speed: 0.002,
                gravity: 500,
                dampening: 0.95,
                minLimit: 10,
                maxLimit: null,
                minDistance: 20,
                maxDistance: 800,
                autopilot: true,
                draw: false,
                bounds: FSS.Vector3.create(),
                step: FSS.Vector3.create(
                    Math.randomInRange(0.2, 1.0),
                    Math.randomInRange(0.2, 1.0),
                    Math.randomInRange(0.2, 1.0)
                )
            };


            /* ------------------------------
                Render Properties
                ------------------------------ */

            var RENDER = {
                renderer: 'canvas'
            };

            var now, start = Date.now();
            var center = FSS.Vector3.create();
            var attractor = FSS.Vector3.create();
            var containerFSS = flatSurface[0];
            var output = flatSurface[0];
            var rendererFSS, sceneFSS, mesh, geometry, material;
            var canvasRenderer;

        }

        /* ------------------------------
            Methods
            ------------------------------ */

        function initialise() {
            createRenderer();
            createScene();
            createMesh();
            createLights();
            addEventListeners();
            resize(containerFSS.offsetWidth, containerFSS.offsetHeight);
            animateFSS();
        }

        function createRenderer() {
            canvasRenderer = new FSS.CanvasRenderer();
            setRenderer(RENDER.renderer);
        }

        function setRenderer() {
            if (rendererFSS) {
                output.removeChild(rendererFSS.element);
            }

            rendererFSS = canvasRenderer;

            rendererFSS.setSize(containerFSS.offsetWidth, containerFSS.offsetHeight);
            output.appendChild(rendererFSS.element);
        }

        function createScene() {
            sceneFSS = new FSS.Scene();
        }

        function createMesh() {
            sceneFSS.remove(mesh);
            rendererFSS.clear();
            geometry = new FSS.Plane(MESH.width * rendererFSS.width, MESH.height * rendererFSS.height, MESH.segments, MESH.slices);
            material = new FSS.Material(MESH.ambient, MESH.diffuse);
            mesh = new FSS.Mesh(geometry, material);
            sceneFSS.add(mesh);

            // Augment vertices for animation
            var v, vertex;
            for (v = geometry.vertices.length - 1; v >= 0; v--) {
                vertex = geometry.vertices[v];
                vertex.anchor = FSS.Vector3.clone(vertex.position);
                vertex.step = FSS.Vector3.create(
                    Math.randomInRange(0.2, 1.0),
                    Math.randomInRange(0.2, 1.0),
                    Math.randomInRange(0.2, 1.0)
                );
                vertex.time = Math.randomInRange(0, Math.PIM2);
            }
        }

        function createLights() {
            var l, light;
            for (l = sceneFSS.lights.length - 1; l >= 0; l--) {
                light = sceneFSS.lights[l];
                sceneFSS.remove(light);
            }
            rendererFSS.clear();
            for (l = 0; l < LIGHT.count; l++) {
                light = new FSS.Light(LIGHT.ambient, LIGHT.diffuse);
                light.ambientHex = light.ambient.format();
                light.diffuseHex = light.diffuse.format();
                sceneFSS.add(light);

                // Augment light for animation
                light.mass = Math.randomInRange(0.5, 1);
                light.velocity = FSS.Vector3.create();
                light.acceleration = FSS.Vector3.create();
                light.force = FSS.Vector3.create();

                // Ring SVG Circle
                light.ring = document.createElementNS(FSS.SVGNS, 'circle');
                light.ring.setAttributeNS(null, 'stroke', light.ambientHex);
                light.ring.setAttributeNS(null, 'stroke-width', '0.5');
                light.ring.setAttributeNS(null, 'fill', 'none');
                light.ring.setAttributeNS(null, 'r', '10');

                // Core SVG Circle
                light.core = document.createElementNS(FSS.SVGNS, 'circle');
                light.core.setAttributeNS(null, 'fill', light.diffuseHex);
                light.core.setAttributeNS(null, 'r', '4');
            }
        }

        function resize(width, height) {
            rendererFSS.setSize(width, height);
            FSS.Vector3.set(center, rendererFSS.halfWidth, rendererFSS.halfHeight);
            createMesh();
        }

        function animateFSS() {
            now = Date.now() - start;
            update();
            renderFSS();
            requestAnimationFrame(animateFSS);
        }

        function update() {
            var ox, oy, oz, l, light, v, vertex, offset = MESH.depth / 2;

            // Update Bounds
            FSS.Vector3.copy(LIGHT.bounds, center);
            FSS.Vector3.multiplyScalar(LIGHT.bounds, LIGHT.xyScalar);

            // Update Attractor
            FSS.Vector3.setZ(attractor, LIGHT.zOffset);

            // Overwrite the Attractor position
            if (LIGHT.autopilot) {
                ox = Math.sin(LIGHT.step[0] * now * LIGHT.speed);
                oy = Math.cos(LIGHT.step[1] * now * LIGHT.speed);
                FSS.Vector3.set(attractor,
                    LIGHT.bounds[0] * ox,
                    LIGHT.bounds[1] * oy,
                    LIGHT.zOffset);
            }

            // Animate Lights
            for (l = sceneFSS.lights.length - 1; l >= 0; l--) {
                light = sceneFSS.lights[l];

                // Reset the z position of the light
                FSS.Vector3.setZ(light.position, LIGHT.zOffset);

                // Calculate the force Luke!
                var D = Math.clamp(FSS.Vector3.distanceSquared(light.position, attractor), LIGHT.minDistance, LIGHT.maxDistance);
                var F = LIGHT.gravity * light.mass / D;
                FSS.Vector3.subtractVectors(light.force, attractor, light.position);
                FSS.Vector3.normalise(light.force);
                FSS.Vector3.multiplyScalar(light.force, F);

                // Update the light position
                FSS.Vector3.set(light.acceleration);
                FSS.Vector3.add(light.acceleration, light.force);
                FSS.Vector3.add(light.velocity, light.acceleration);
                FSS.Vector3.multiplyScalar(light.velocity, LIGHT.dampening);
                FSS.Vector3.limit(light.velocity, LIGHT.minLimit, LIGHT.maxLimit);
                FSS.Vector3.add(light.position, light.velocity);
            }

            // Animate Vertices
            for (v = geometry.vertices.length - 1; v >= 0; v--) {
                vertex = geometry.vertices[v];
                ox = Math.sin(vertex.time + vertex.step[0] * now * MESH.speed);
                oy = Math.cos(vertex.time + vertex.step[1] * now * MESH.speed);
                oz = Math.sin(vertex.time + vertex.step[2] * now * MESH.speed);
                FSS.Vector3.set(vertex.position,
                    MESH.xRange * geometry.segmentWidth * ox,
                    MESH.yRange * geometry.sliceHeight * oy,
                    MESH.zRange * offset * oz - offset);
                FSS.Vector3.add(vertex.position, vertex.anchor);
            }

            // Set the Geometry to dirty
            geometry.dirty = true;
        }

        function renderFSS() {
            rendererFSS.render(sceneFSS);

            // Draw Lights
            if (LIGHT.draw) {
                var l, lx, ly, light;
                for (l = sceneFSS.lights.length - 1; l >= 0; l--) {
                    light = sceneFSS.lights[l];
                    lx = light.position[0];
                    ly = light.position[1];
                    rendererFSS.context.lineWidth = 0.5;
                    rendererFSS.context.beginPath();
                    rendererFSS.context.arc(lx, ly, 10, 0, Math.PIM2);
                    rendererFSS.context.strokeStyle = light.ambientHex;
                    rendererFSS.context.stroke();
                    rendererFSS.context.beginPath();
                    rendererFSS.context.arc(lx, ly, 4, 0, Math.PIM2);
                    rendererFSS.context.fillStyle = light.diffuseHex;
                    rendererFSS.context.fill();

                }
            }
        }


        function addEventListeners() {
            window.addEventListener('resize', onWindowResizFSS);
        }

        /* ------------------------------
            Callbacks
            ------------------------------ */

        function onWindowResizFSS() {
            resize(containerFSS.offsetWidth, containerFSS.offsetHeight);
            renderFSS();
        }


        // Init
        if (flatSurface.length) {
            initialise();
        }
    },
    'scroll': function () {

    }
});