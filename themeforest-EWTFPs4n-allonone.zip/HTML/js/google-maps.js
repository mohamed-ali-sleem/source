/**
 * Google Maps
 */

var map;
function initMap() {
    var latitude = $('#map').data('latitude')
    var longitude = $('#map').data('longitude')
    var myLatLng = { lat: latitude, lng: longitude };

    var mapOptions = {
        zoom: 12,
        center: myLatLng,

        scrollwheel: false
    };
    var contentString = '<div class="info"><p> Insert Your data here as HTML </p></div> '  ;

    var infowindow = new google.maps.InfoWindow({
        content: contentString
    });
    map = new google.maps.Map(document.getElementById('map'), mapOptions);

    var image = 'images/map-marker.png';
    var marker = new google.maps.Marker({
        position: myLatLng,
        map: map,
        icon: image,
        title: 'Your Company here'
    });
    marker.addListener('click', function () {
        infowindow.open(map, marker);
    });
}