﻿/* Custom JS */ 
'use strict'; 
var $window = $(window); 
$window.on({
    'load': function () {

        /* Preloader */ 
        $(".loader").fadeOut();  
      
        var text = $(".typewriter").data('text'); // Text that we need to write under logo
        //text is split up to letters
        $.each(text.split(''), function (i, letter) {
            //we add 50 * i ms delay to each letter 
            setTimeout(function () {
                //we add the letter to the container
                $('.typewriter').text($('.typewriter').text() + letter);
            }, 50 * i);
        });


        /* Smooth scroll to anchor */ 
        $('a[href*="#"]').not('[href="#"], [data-slide], [data-toggle]').on('click touchend', function () {
            if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') && location.hostname === this.hostname) { 
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    $('html, body').animate({
                        scrollTop: target.offset().top - 65
                    }, 1000);
                    return false;
                }
            }
        });
       

        /* Navbar class toggle */

        // Toggle navbar on page load if needed
        var scrollTop = $window.scrollTop(),
			$navbar = $('.navbar'),
			$navbarDefault = $('.navbar-default'),
			$navbarInverse = $('.navbar-inverse'),
			$navbarCollapse = $(".navbar-collapse");

        //if (scrollTop > 0) {
        //    $navbar.toggleClass("navbar-default navbar-inverse");
        //}

        // Toggle navbar on collapse
        $navbarCollapse.on({
            'show.bs.collapse': function () {
                $navbar.removeClass("navbar-default").addClass("navbar-inverse");
            },
            'hidden.bs.collapse': function () {
                var scrollTop = $window.scrollTop();

                if (scrollTop === 0) {
                    $navbar.removeClass("navbar-inverse").addClass("navbar-default");
                }
            }
        });

        //======= Youtube Video Background ========//
        $('.video-bg').YTPlayer({
            fitToBackground: true,
            videoId: 'wevJGIJXDFc'//Set Your Youtube Video ID
        });


        /* Touchable Device Swipe */
        /*
          I've got this code from an article Adding swipe support to Bootstrap Carousel 3.0 by Mr Justin Lazanowski.
           you Can Review via This Links: http://lazcreative.com/blog/adding-swipe-support-to-bootstrap-carousel-3-0/ or http://lazcreative.com/blog/adding-swipe-support-to-bootstrap-carousel-3-0/
        */
    
        var width = $window.width()
        if ((width > 1024)) {
            $(".carousel-inner").swipe({
                //Generic swipe handler for all directions
                swipeDown: function (event, direction, distance, duration, fingerCount) {
                    $(this).parent().carousel('prev');
                },
                swipeUp: function () {
                    $(this).parent().carousel('next');
                },
                threshold: 0
            });
        }
        else {
            $(".carousel-inner").swipe("disable"); //disable touch in mobile version
        }

        /* Carousel text and buttons animation*/
        //Splite Charaters in Span to do Animations

        $(".splite").html(function (index, html) {
            return html.replace(/\S/g, '<span>$&</span>');
        });
        //Add Animation Delay for Spans
        var animationDelay = .05;
        var n = $(".split-container span").length;
        for (var i = 1; i < n; i++) {
            // don't Worry about Vendor Prefixes As of jQuery 1.8, the .css() setter will automatically take care of prefixing the property name
            $(".split-container span:nth-child(" + i + "n)").css("animation-delay", animationDelay + "s");
            animationDelay += .05;
        }
        // animate item contents

        var animationsItems = $(".split-container span"),
            animationsButton = $(".split-container a");
        function animationContents() {
            $(animationsItems).addClass("rotateIn animated").delay(20000).queue(function (next) {
                $(this).removeClass("rotateIn animated");
                next();
            });
            $(animationsButton).addClass("bounceInLeft animated").delay(2000000).queue(function (next) {
                $(this).removeClass("bounceLeft animated");
                next();

            });
        }
        animationContents(); // Call animate css when page load This Call is responsible to run first slide animations
        // cache $(".carousel") in variable Because of that I will use this Selector more than once
        var $carousel = $(".carousel");
        $carousel.carousel(); //Initialize carousel (you Can See documentation of Bootstrap Carousel)
        //Other slides to be animated on carousel slide event
        $carousel.on("slide.bs.carousel", function (e) { // This event fires immediately when the slide instance method is invoked.
            animationContents(); // Call animationContents()
        });

        /* Control Slide Animation Duration */
        var itemDurVal = $($carousel).data("duration"); /*get data-duration value of my carousel */
        $(".split-container").css({
            "transition-duration": itemDurVal + "ms"
        });
         
        /* Animate With Wow JS */
        new WOW().init(); 
       
        /* Owl Services Carousel */
        $('#mobile-slider').owlCarousel({
            loop: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 1
                }
            },
            dots: false,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true
        });

        /* Init Counter */
        $('.counter').counterUp({ delay: 10, time: 3000 });

        /* Owl Team Carousel */
        $(".team-List").owlCarousel({
            loop: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 3
                }
            },
            dots: false,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true
        }); 

        /* Portfolio modal */
        $('#portfolioModal').on('show.bs.modal', function (event) {
            var link = $(event.relatedTarget) // Button that triggered the modal
            var recipient = link.data('img') // Extract info from data-* attributes
            // Update the modal's content.
            var modal = $(this);
            modal.find('.modal-body img').attr({
                'src': recipient,
                'alt': 'project_title'
            });

        });

        /*Portfolio (filtering) */

        // Init Isotope
        var $portfolio = $(".portfolio-boxes").isotope({
            itemSelector: ".portfolio-box",
            layoutMode: "masonry"
        });

        // Set initial filtering
        $portfolio.isotope({ filter: ".all" });

        // Filter items on click
        $(".portfolio-nav > a").on('click', function (e) { 
            // Filter items 
            var filterValue = $(this).attr('data-filter');
            $portfolio.isotope({
                filter: filterValue
            }); 
            // Change active button
            $(this).addClass("active").siblings("a").removeClass("active"); 
            e.preventDefault();
        }); 

        /* Owl Testimonials Carousel */
        $(".testimonials-List").owlCarousel({
            loop: true,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 1
                },
                1000: {
                    items: 1
                }
            },
            dots: true,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true
        });

        /* Owl Client Carousel */
        $("#client").owlCarousel({
            loop: true,
            responsive: {
                0: {
                    items: 2
                },
                600: {
                    items: 4
                },
                1000: {
                    items: 6
                }
            },
            dots: false,
            autoplay: true,
            autoplayTimeout: 2000,
            autoplayHoverPause: true

        });

        /* Contact form */
        var form = $('#contact-form');
        form.submit(function (event) {
            event.preventDefault();
            var form_status = $('<div class="form-status"></div>');
            $.ajax({
                url: $(this).attr('action'),
                beforeSend: function () {
                    form.prepend(form_status.html('<p><i class="fa fa-spinner fa-spin"></i> Email is sending...</p>').fadeIn());
                }
            }).done(function (data) {
                form_status.html('<div id="alert" class="alert alert-success">Thank you for contact us. As early as possible  we will contact you  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            });
        });  
 
        
    },
    'scroll': function () { 
    
        /* Toggle navbar on scroll */ 
        var currentScrollTop = $window.scrollTop(),
 			$navbar = $('.navbar'),
			$navbarDefault = $('.navbar-default'),
			$navbarInverse = $('.navbar-inverse');

        if (currentScrollTop > 0 && $navbarDefault.length) {
             $navbar.removeClass("navbar-default").addClass("navbar-inverse");
        } else if (currentScrollTop === 0) {
             $navbar.removeClass("navbar-inverse").addClass("navbar-default");
        }
         
    }
});