﻿/* Custom JS */ 
'use strict'; 
var $window = $(window),
    $document = $(document);
document.write('<script async src="https://www.youtube.com/iframe_api"></script>'); 

$window.on({
    'load': function () {

        // =================================================================================
        // Preloader
        // =================================================================================
        $(".preloader").fadeOut();

        //----------------------------------------------------------------------------------------
        // progress bar
        //----------------------------------------------------------------------------------------
        var $progressBar = $(".progress .progress-bar");
        var $skills = $('.my-skill');

        if ($skills.length) {
            $skills.appear(function () {
                $progressBar.each(function () {
                    var innerWidth = $(this).data("width");
                    $(this).animate({
                        width: innerWidth
                    }, { duration: 1000 });
                });
            });
        }

        // =================================================================================
        // Smooth scroll to anchor 
        // =================================================================================
        $('a[href*="#"]').not('[href="#"], [data-slide], [data-toggle]').on('click touchend', function () {
            if (location.pathname.replace(/^\//, '') === this.pathname.replace(/^\//, '') && location.hostname === this.hostname) {
                var target = $(this.hash);
                target = target.length ? target : $('[name=' + this.hash.slice(1) + ']');
                if (target.length) {
                    $('html, body').animate({
                        scrollTop: target.offset().top - 65
                    }, 1000);
                    return false;
                }
            }
        });


        // =================================================================================
        // Background ripple
        // =================================================================================
        var $ripple = $('#page-ripple');

        if ($ripple.length) {
            $ripple.ripples({
                resolution: 512,
                dropRadius: 100, //px
                perturbance: 0.01,
                interactive: false
            });

            setInterval(function () {
                var $el = $ripple;
                var x = Math.random() * $el.outerWidth();
                var y = Math.random() * $el.outerHeight();
                var dropRadius = 20;
                var strength = 0.04 + Math.random() * 0.01;

                $el.ripples('drop', x, y, dropRadius, strength);
            }, 500);
        }
        // =================================================================================
        //  Background Flat Surface Shader
        // =================================================================================
        /* ------------------------------
         Options
         ------------------------------ */

        var $flatSurface = $('#bg-fss');

        if ($flatSurface.length) {
            var MESH = {
                width: 1.2,
                height: 1.2,
                depth: 0,
                segments: 16,
                slices: 8,
                xRange: 0.8,
                yRange: 0.1,
                zRange: 1.0,
                ambient: '#555555',
                diffuse: '#ffffff',
                speed: 0.002
            };

            var LIGHT = {
                count: 2,
                xyScalar: 1,
                zOffset: 100,
                ambient: $flatSurface.data('ambient'),
                diffuse: $flatSurface.data('diffuse'),
                speed: 0.002,
                gravity: 500,
                dampening: 0.95,
                minLimit: 10,
                maxLimit: null,
                minDistance: 20,
                maxDistance: 800,
                autopilot: true,
                draw: false,
                bounds: FSS.Vector3.create(),
                step: FSS.Vector3.create(
                  Math.randomInRange(0.2, 1.0),
                  Math.randomInRange(0.2, 1.0),
                  Math.randomInRange(0.2, 1.0)
                )
            };


            /* ------------------------------
             Render Properties
             ------------------------------ */

            var RENDER = {
                renderer: 'canvas'
            };

            var now, start = Date.now();
            var center = FSS.Vector3.create();
            var attractor = FSS.Vector3.create();
            var containerFSS = $flatSurface[0];
            var output = $flatSurface[0];
            var rendererFSS, sceneFSS, mesh, geometry, material;
            var canvasRenderer;

        }

        /* ------------------------------
         Methods
         ------------------------------ */

        function initialise() {
            createRenderer();
            createScene();
            createMesh();
            createLights();
            addEventListeners();
            resize(containerFSS.offsetWidth, containerFSS.offsetHeight);
            animateFSS();
        }

        function createRenderer() {
            canvasRenderer = new FSS.CanvasRenderer();
            setRenderer(RENDER.renderer);
        }

        function setRenderer() {
            if (rendererFSS) {
                output.removeChild(rendererFSS.element);
            }

            rendererFSS = canvasRenderer;

            rendererFSS.setSize(containerFSS.offsetWidth, containerFSS.offsetHeight);
            output.appendChild(rendererFSS.element);
        }

        function createScene() {
            sceneFSS = new FSS.Scene();
        }

        function createMesh() {
            sceneFSS.remove(mesh);
            rendererFSS.clear();
            geometry = new FSS.Plane(MESH.width * rendererFSS.width, MESH.height * rendererFSS.height, MESH.segments, MESH.slices);
            material = new FSS.Material(MESH.ambient, MESH.diffuse);
            mesh = new FSS.Mesh(geometry, material);
            sceneFSS.add(mesh);

            // Augment vertices for animation
            var v, vertex;
            for (v = geometry.vertices.length - 1; v >= 0; v--) {
                vertex = geometry.vertices[v];
                vertex.anchor = FSS.Vector3.clone(vertex.position);
                vertex.step = FSS.Vector3.create(
                  Math.randomInRange(0.2, 1.0),
                  Math.randomInRange(0.2, 1.0),
                  Math.randomInRange(0.2, 1.0)
                );
                vertex.time = Math.randomInRange(0, Math.PIM2);
            }
        }

        function createLights() {
            var l, light;
            for (l = sceneFSS.lights.length - 1; l >= 0; l--) {
                light = sceneFSS.lights[l];
                sceneFSS.remove(light);
            }
            rendererFSS.clear();
            for (l = 0; l < LIGHT.count; l++) {
                light = new FSS.Light(LIGHT.ambient, LIGHT.diffuse);
                light.ambientHex = light.ambient.format();
                light.diffuseHex = light.diffuse.format();
                sceneFSS.add(light);

                // Augment light for animation
                light.mass = Math.randomInRange(0.5, 1);
                light.velocity = FSS.Vector3.create();
                light.acceleration = FSS.Vector3.create();
                light.force = FSS.Vector3.create();

                // Ring SVG Circle
                light.ring = document.createElementNS(FSS.SVGNS, 'circle');
                light.ring.setAttributeNS(null, 'stroke', light.ambientHex);
                light.ring.setAttributeNS(null, 'stroke-width', '0.5');
                light.ring.setAttributeNS(null, 'fill', 'none');
                light.ring.setAttributeNS(null, 'r', '10');

                // Core SVG Circle
                light.core = document.createElementNS(FSS.SVGNS, 'circle');
                light.core.setAttributeNS(null, 'fill', light.diffuseHex);
                light.core.setAttributeNS(null, 'r', '4');
            }
        }

        function resize(width, height) {
            rendererFSS.setSize(width, height);
            FSS.Vector3.set(center, rendererFSS.halfWidth, rendererFSS.halfHeight);
            createMesh();
        }

        function animateFSS() {
            now = Date.now() - start;
            update();
            renderFSS();
            requestAnimationFrame(animateFSS);
        }

        function update() {
            var ox, oy, oz, l, light, v, vertex, offset = MESH.depth / 2;

            // Update Bounds
            FSS.Vector3.copy(LIGHT.bounds, center);
            FSS.Vector3.multiplyScalar(LIGHT.bounds, LIGHT.xyScalar);

            // Update Attractor
            FSS.Vector3.setZ(attractor, LIGHT.zOffset);

            // Overwrite the Attractor position
            if (LIGHT.autopilot) {
                ox = Math.sin(LIGHT.step[0] * now * LIGHT.speed);
                oy = Math.cos(LIGHT.step[1] * now * LIGHT.speed);
                FSS.Vector3.set(attractor,
                  LIGHT.bounds[0] * ox,
                  LIGHT.bounds[1] * oy,
                  LIGHT.zOffset);
            }

            // Animate Lights
            for (l = sceneFSS.lights.length - 1; l >= 0; l--) {
                light = sceneFSS.lights[l];

                // Reset the z position of the light
                FSS.Vector3.setZ(light.position, LIGHT.zOffset);

                // Calculate the force Luke!
                var D = Math.clamp(FSS.Vector3.distanceSquared(light.position, attractor), LIGHT.minDistance, LIGHT.maxDistance);
                var F = LIGHT.gravity * light.mass / D;
                FSS.Vector3.subtractVectors(light.force, attractor, light.position);
                FSS.Vector3.normalise(light.force);
                FSS.Vector3.multiplyScalar(light.force, F);

                // Update the light position
                FSS.Vector3.set(light.acceleration);
                FSS.Vector3.add(light.acceleration, light.force);
                FSS.Vector3.add(light.velocity, light.acceleration);
                FSS.Vector3.multiplyScalar(light.velocity, LIGHT.dampening);
                FSS.Vector3.limit(light.velocity, LIGHT.minLimit, LIGHT.maxLimit);
                FSS.Vector3.add(light.position, light.velocity);
            }

            // Animate Vertices
            for (v = geometry.vertices.length - 1; v >= 0; v--) {
                vertex = geometry.vertices[v];
                ox = Math.sin(vertex.time + vertex.step[0] * now * MESH.speed);
                oy = Math.cos(vertex.time + vertex.step[1] * now * MESH.speed);
                oz = Math.sin(vertex.time + vertex.step[2] * now * MESH.speed);
                FSS.Vector3.set(vertex.position,
                  MESH.xRange * geometry.segmentWidth * ox,
                  MESH.yRange * geometry.sliceHeight * oy,
                  MESH.zRange * offset * oz - offset);
                FSS.Vector3.add(vertex.position, vertex.anchor);
            }

            // Set the Geometry to dirty
            geometry.dirty = true;
        }

        function renderFSS() {
            rendererFSS.render(sceneFSS);

            // Draw Lights
            if (LIGHT.draw) {
                var l, lx, ly, light;
                for (l = sceneFSS.lights.length - 1; l >= 0; l--) {
                    light = sceneFSS.lights[l];
                    lx = light.position[0];
                    ly = light.position[1];
                    rendererFSS.context.lineWidth = 0.5;
                    rendererFSS.context.beginPath();
                    rendererFSS.context.arc(lx, ly, 10, 0, Math.PIM2);
                    rendererFSS.context.strokeStyle = light.ambientHex;
                    rendererFSS.context.stroke();
                    rendererFSS.context.beginPath();
                    rendererFSS.context.arc(lx, ly, 4, 0, Math.PIM2);
                    rendererFSS.context.fillStyle = light.diffuseHex;
                    rendererFSS.context.fill();

                }
            }
        }


        function addEventListeners() {
            window.addEventListener('resize', onWindowResizFSS);
        }

        /* ------------------------------
         Callbacks
         ------------------------------ */

        function onWindowResizFSS() {
            resize(containerFSS.offsetWidth, containerFSS.offsetHeight);
            renderFSS();
        }


        // Init
        if ($flatSurface.length) {
            initialise();
        }
        // =================================================================================
        // mainSlider
        // =================================================================================
        var $mainSlider = $('#main-slider');
        if ($mainSlider.length) {
            $mainSlider.owlCarousel({
                nav: true,
                loop: true,
                autoplay: true,
                margin: 0,
                navText: ["<a><span></span></a>", "<a><span></span></a>"],
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1e3: { items: 1 }
                }
            });
        }
        // =================================================================================
        // blog-carsoule
        // ================================================================================= 
        var $blogCarsoule = $('.active-blog-carsoule');
        if ($blogCarsoule.length) {
            $blogCarsoule.owlCarousel({
                loop: true,
                animateOut: 'fadeOut',
                animateIn: 'fadeIn',
                items: 3,
                dots: false,
                nav: false,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: 3
                    }
                }
            });
        }

        // =================================================================================
        // tooltip intialize
        // ================================================================================= 
        $('[data-toggle="tooltip"]').tooltip();


        // =================================================================================
        // fancybox intialize
        // ================================================================================= 
        $('[data-fancybox]').fancybox({
            image: {
                protect: true
            }
        });

        // =================================================================================
        // Image Slider
        // =================================================================================

        var $imgSlider = $('#slides');
        if ($imgSlider.length) {
            $imgSlider.superslides({
                animation: 'fade',
                play: 10000
            });
        }

        // =================================================================================
        // Youtube Video Background 
        // ================================================================================= 
        var $video = $('.bg-video');
        if ($video.length) {
            $video.YTPlayer();
        }

        // =================================================================================
        // circle bar
        // ================================================================================= 
        //$('.progress-bar').appear(function () {
        //    $(this).css('width', $(this).data('progress') + '%'); 
        //});

        $('.circle-bar-wrap').each(function (index, el) {
            $(el).appear(function () {

                var options = {
                    color: $(el).data('color'),
                    number: $(el).data('number'),
                    trailColor: $(el).data('color') == '#fff' ? 'rgba(255,255,255,0.25)' : '#eee'
                }

                var bar = new ProgressBar.Circle(el, {
                    strokeWidth: 1,
                    easing: 'easeInOut',
                    duration: 1400,
                    color: options.color,
                    trailColor: options.trailColor,
                    trailWidth: 1,
                    svgStyle: null,
                    text: {
                        autoStyleContainer: false
                    },
                    from: { color: options.color, width: 1 },
                    to: { color: options.color, width: 1 },
                    step: function (state, circle) {
                        circle.path.setAttribute('stroke', state.color);
                        circle.path.setAttribute('stroke-width', state.width);

                        var value = Math.round(circle.value() * 100);
                        if (value === 0) {
                            circle.setText('');
                        } else {
                            circle.setText(value);
                        }

                    }
                });

                bar.animate(options.number / 100);

            });

        });
        // =================================================================================
        // Animate With Wow JS
        // ================================================================================= 
        new WOW().init();

        // =================================================================================
        //  Init Counter *
        // =================================================================================
        var $counter = $('.counter');
        if ($counter.length) {
            $('.counter').counterUp({
                delay: 10,
                time: 3000
            });
        }

        // =================================================================================
        // Owl Team Carousel
        // =================================================================================
        var $team = $('.team-List');
        if ($team.length) {
            $team.owlCarousel({
                loop: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 2
                    },
                    1000: {
                        items: 3
                    }
                },
                dots: false,
                autoplay: true,
                autoplayTimeout: 2000,
                autoplayHoverPause: true
            });
        }

        // =================================================================================
        // Portfolio (filtering)
        // =================================================================================
        var $portfolios = $('.portfolio-boxes');
        if ($portfolios.length) {
            // init Isotope
            var $portfolio = $('.portfolio-boxes').isotope({
                itemSelector: '.portfolio-box',
                percentPosition: true,
                masonry: {
                    // use outer width of grid-sizer for columnWidth
                    columnWidth: '.portfolio-box',
                }
            });
        }
        // Filter items on click
        $(".portfolio-nav > a").on('click', function (e) {
            // Filter items 
            var filterValue = $(this).attr('data-filter');
            $portfolio.isotope({
                filter: filterValue
            });
            // Change active button
            $(this).addClass("active").siblings("a").removeClass("active");
            e.preventDefault();
        });

        // =================================================================================
        // Owl Testimonials Carousel
        // =================================================================================
        var $testimonials = $('.testimonials-List');
        if ($testimonials.length) {
            $testimonials.owlCarousel({
                loop: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1000: {
                        items: 1
                    }
                },
                dots: true,
                autoplay: true,
                autoplayTimeout: 2000,
                autoplayHoverPause: true
            });
        }
        // =================================================================================
        // Owl Client Carousel
        // =================================================================================
        var $client = $('#client');
        if ($client.length) {
            $client.owlCarousel({
                loop: true,
                responsive: {
                    0: {
                        items: 2
                    },
                    600: {
                        items: 4
                    },
                    1000: {
                        items: 6
                    }
                },
                dots: false,
                autoplay: true,
                autoplayTimeout: 2000,
                autoplayHoverPause: true

            });
        }
        // =================================================================================
        // Contact form
        // =================================================================================
        var form = $('#contact-form');
        form.submit(function (event) {
            event.preventDefault();
            var form_status = $('<div class="form-status"></div>');
            $.ajax({
                url: $(this).attr('action'),
                beforeSend: function () {
                    form.prepend(form_status.html('<p><i class="fa fa-spinner fa-spin"></i> Email is sending...</p>').fadeIn());
                }
            }).done(function (data) {
                form_status.html('<div id="alert" class="alert alert-success">Thank you for contact us. As early as possible  we will contact you  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');
            });
        });

        // =================================================================================
        // particlesjs
        // =================================================================================
        var $particles_js = $('#particles-js');
        if ($particles_js.length) {
            var lineColor = $particles_js.data('line');
            var pointColor = $particles_js.data('point');
            particlesJS('particles-js',
              {
                  "particles": {
                      "number": {
                          "value": 100,
                          "density": {
                              "enable": true,
                              "value_area": 800
                          }
                      },
                      "color": {
                          "value": pointColor
                      },
                      "shape": {
                          "type": "circle",
                          "stroke": {
                              "width": 0,
                              "color": pointColor
                          },
                          "polygon": {
                              "nb_sides": 5
                          },
                          "image": {
                              "src": "img/github.svg",
                              "width": 100,
                              "height": 100
                          }
                      },
                      "opacity": {
                          "value": 0.5,
                          "random": false,
                          "anim": {
                              "enable": false,
                              "speed": 1,
                              "opacity_min": 0.1,
                              "sync": false
                          }
                      },
                      "size": {
                          "value": 5,
                          "random": true,
                          "anim": {
                              "enable": false,
                              "speed": 40,
                              "size_min": 0.1,
                              "sync": false
                          }
                      },
                      "line_linked": {
                          "enable": true,
                          "distance": 150,
                          "color": lineColor,
                          "opacity": 0.4,
                          "width": 1
                      },
                      "move": {
                          "enable": true,
                          "speed": 6,
                          "direction": "none",
                          "random": false,
                          "straight": false,
                          "out_mode": "out",
                          "attract": {
                              "enable": false,
                              "rotateX": 600,
                              "rotateY": 1200
                          }
                      }
                  },
                  "interactivity": {
                      "detect_on": "canvas",
                      "events": {
                          "onhover": {
                              "enable": true,
                              "mode": "repulse"
                          },
                          "onclick": {
                              "enable": true,
                              "mode": "push"
                          },
                          "resize": true
                      },
                      "modes": {
                          "grab": {
                              "distance": 400,
                              "line_linked": {
                                  "opacity": 1
                              }
                          },
                          "bubble": {
                              "distance": 400,
                              "size": 40,
                              "duration": 2,
                              "opacity": 8,
                              "speed": 3
                          },
                          "repulse": {
                              "distance": 200
                          },
                          "push": {
                              "particles_nb": 4
                          },
                          "remove": {
                              "particles_nb": 2
                          }
                      }
                  },
                  "retina_detect": true,
                  "config_demo": {
                      "hide_card": false,
                      "background_color": "#b61924",
                      "background_image": "",
                      "background_position": "50% 50%",
                      "background_repeat": "no-repeat",
                      "background_size": "cover"
                  }
              }

            );
        }

        // =================================================================================
        // Google Maps
        // =================================================================================
        var map;
        function initMap() {
            var latitude = $('#map').data('latitude');
            var longitude = $('#map').data('longitude');
            var myLatLng = { lat: latitude, lng: longitude };

            var mapOptions = {
                zoom: 12,
                center: myLatLng,

                scrollwheel: false
            };
            var contentString = '<div class="info"><p> Insert Your data here as HTML </p></div> ';

            var infowindow = new google.maps.InfoWindow({
                content: contentString
            });
            map = new google.maps.Map(document.getElementById('map'), mapOptions);

            //var image = 'images/map-marker.png';
            var marker = new google.maps.Marker({
                position: myLatLng,
                map: map,
                //icon: image,
                title: 'Your Company here'
            });
            marker.addListener('click', function () {
                infowindow.open(map, marker);
            });
        }

        /* Owl Services Carousel */
        var $mobile_slider = $('#mobile-slider');
        if ($mobile_slider.length) {
            $mobile_slider.owlCarousel({
                loop: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    600: {
                        items: 1
                    },
                    1000: {
                        items: 1
                    }
                },
                dots: false,
                autoplay: true,
                autoplayTimeout: 2000,
                autoplayHoverPause: true
            });
        }

    },

    'scroll': function () {
        /* Toggle navbar on scroll */
        var o = $(window).width();
        o > 767 && $(this).scrollTop() > 50 ? $(".navigation").removeClass("navbar-expanded") : $(".navigation").addClass("navbar-expanded");

    }
});